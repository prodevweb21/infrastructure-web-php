<?php
$username="urgwlg19_utilisateuradmin";
$password="bA*OSD}m_veK";
$host="localhost";
$database="urgwlg19_projetnouvelles";
?>